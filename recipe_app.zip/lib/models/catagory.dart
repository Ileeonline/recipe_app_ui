const catgories = [
  "All",
  "Breakfast",
  "Lunch",
  "Dinner",
];