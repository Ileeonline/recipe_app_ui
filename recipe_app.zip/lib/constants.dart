import 'package:flutter/material.dart';

const kbackgroundColor = Color(0xffEEF1F6);
const kprimaryColor = Color(0xff568A9F);